Place any jars here that you wish for phoenix to copy to $PHOENIX_HOME/ext when a distribution is created.
